package sedz03;

/***********************************************************************
 * Module:  AlertType.java
 * Author:  User
 * Purpose: Defines the Class AlertType
 ***********************************************************************/

import java.util.*;
import javafx.scene.control.TextField;

/** @pdOid a0854876-0f43-4f99-9db0-97516a2f8753 */
public enum AlertType {
   success,
   error;

   /** @pdOid efeb6bf7-17f0-4da3-9b5e-81a7d05adc69 */
   public class ZakazivanjeGUI {
      /** @pdOid 0d119912-47dc-4a4f-90b0-5d5b0e4721e7 */
      private TextField jmbgPosetioca;
      /** @pdOid e76604a2-1465-4840-97bf-c2eeee7fddc3 */
      private TextField jmbgPacijenta;
      /** @pdOid ecf0a0d0-c04a-4e9a-919c-18a14dbd8be2 */
      private Date datumPosete;
      
      /**
        * @return  *  @pdOid ae653787-0062-4a84-9999-dbda7e11697c */
      /** @pdOid 8a6547f5-315f-4156-8689-ae6a68e48996 */
      public void otvoriZakazivanjeGUI() {
         // TODO: implement
      }
      
      /** @param poruka 
       * @param tipPoruke
       * @pdOid 7e13543f-d5e1-4b95-b842-ab4508c237ac */
      public void prikazPoruke(String poruka, AlertType tipPoruke) {
         // TODO: implement
      }
      
      /** @pdOid 428fbc7c-9242-48bc-9ea7-bcbcf74b6c68 */
      public void sacuvajZakazazanuPosetu() {
         // TODO: implement
      }
   
   }
   
   /** @pdOid e671dcc3-6537-43c7-80a0-bf1d9b102129 */
   public class BrisanjePoseteGUI {
      /**
        * @return  *  @pdOid 8632f9d1-9407-48ad-a20e-96c2e5e7107a */
      /**
        * @return  *  @pdOid 82f07066-56fa-4c7a-984e-5964a94cd5b5 */
      /** @pdOid 08a93005-b6db-4366-a3fd-302f2bfff8df */
      public void otvoriBrisanjePoseteGUI() {
         // TODO: implement
      }
      
      /** @param poruka 
       * @param tipPoruke
       * @pdOid fd1b10e9-1ab3-4abc-aa5b-b8f46d675c48 */
      public void prikazPoruke(String poruka, AlertType tipPoruke) {
         // TODO: implement
      }
   
   }
   
   /** @pdOid 02f8d4df-708b-4a70-8a62-9d44b91c6342 */
   public class AdministracijaPacijentaGUI {
      /** @pdOid ed107abc-3842-4386-a9a2-56b4a24d7b90 */
      private TextField jmbgPacijenta;
      /** @pdOid 654ff61d-d376-4c4b-b2b6-048cf507924a */
      private TextField imePacijenta;
      /** @pdOid 1ca17927-12ff-4b83-9c14-8ca92f29f256 */
      private TextField prezimePacijenta;
      /** @pdOid d8f75df8-7ed2-42c0-8c97-d17bd0b518dc */
      private TextField stepenBolesti;
      
      /** @param poruka 
       * @param tipPoruke
       * @pdOid 1e434bf6-ed2c-425c-9250-97830be9aaf9 */
      public void prikazPoruke(String poruka, AlertType tipPoruke) {
         // prikazivanje poruke
      }
      
      /** @pdOid 4cb5524e-420c-4bd6-8d0e-6478405986ed */
      public void otvoriAdministracijuPacijentaGUI() {
         // otvaranje admin stranice
      }
      
      /** @pdOid ab7ebcbd-9023-4c45-a3a8-08ca671f70e1 */
      public void sacuvajIzmenu() {
         // cuvanje izmene 
      }
      
      /** @pdOid ce20b6e0-4ec3-41d2-923c-51fbcb101613 */
      public void izbrisiPacijenta() {
         // brisanje izabranog pacijenta
      }
      
      /** @pdOid fca3250c-a6cb-422b-b10e-19489c4ee916 */
      public void pregledPacijenta() {
         // pregled izabranog pacijenta
      }
      
      /** @pdOid f0f5e660-282c-41b9-b3f9-97ba06611bdc */
      public void dodajPacijenta() {
         // dodavanje novog pacijenta
      }
   
   }

}