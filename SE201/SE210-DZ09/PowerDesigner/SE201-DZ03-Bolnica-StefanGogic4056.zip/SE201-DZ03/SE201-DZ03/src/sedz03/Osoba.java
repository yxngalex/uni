package sedz03;

/***********************************************************************
 * Module:  Osoba.java
 * Author:  User
 * Purpose: Defines the Class Osoba
 ***********************************************************************/

/** @pdOid 363b7110-f743-43fe-bf6e-34725f3b54e0 */
public abstract class Osoba {
   /** @pdOid 3049964d-5e4d-47ca-b4db-bc330fc61c63 */
   private String ime;
   /** @pdOid d60991d3-2d78-4a3c-a638-d197def513bc */
   private String prezime;
   
   /**
     * @return  *  @pdOid 0ab861c7-ed48-440e-8265-12f95f6e58d0 */
   public String getIme() {
      return ime;
   }
   
   /** @param newIme
    * @pdOid ab4d869f-f168-439f-a32c-4f962eb71b2a */
   public void setIme(String newIme) {
      ime = newIme;
   }
   
   /**
     * @return  *  @pdOid 857365bd-3e3e-4b09-b0e1-d972245d22b3 */
   public String getPrezime() {
      return prezime;
   }
   
   /** @param newPrezime
    * @pdOid b5e6f280-9037-43c7-a1c9-8e7088e0dc3c */
   public void setPrezime(String newPrezime) {
      prezime = newPrezime;
   }
   
   /** @pdOid c11c0c5a-63a4-42be-9fc5-ae0df226e899 */
   public Osoba() {
      // TODO: implement
   }
   
   /** @param ime 
    * @param prezime
    * @pdOid 7cf47095-716e-4c7e-8b76-133e23637347 */
   public Osoba(String ime, String prezime) {
      // TODO: implement
   }

}