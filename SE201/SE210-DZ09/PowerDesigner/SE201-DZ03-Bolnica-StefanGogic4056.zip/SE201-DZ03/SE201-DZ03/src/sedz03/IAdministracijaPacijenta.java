package sedz03;

/***********************************************************************
 * Module:  IAdministracijaPacijenta.java
 * Author:  User
 * Purpose: Defines the Interface IAdministracijaPacijenta
 ***********************************************************************/

import java.util.*;

/** @pdOid f0b319a4-e837-40fb-9b30-28d7c38cd97c */
public interface IAdministracijaPacijenta {
   /** @param jmbgPacijenta
    * @pdOid e1b26a37-ecff-4653-a122-1592c3a5c396 */
   void obrisiPacijenta(String jmbgPacijenta);
   /** *  @param jmbgPacijenta
     * @return 
    * @pdOid 9f985789-d760-444b-9706-abad5d4be559 */
   Pacijent pogledajPodatkeOPacijentu(String jmbgPacijenta);
   /** @param jmbg 
    * @param imePacijenta 
    * @param prezimePacijenta 
    * @param stepenBolesti 
    * @param idBrojIzabranogDoktora
    * @pdOid 511a723d-a171-4d70-b6d3-18ec141228a9 */
   void dodajPacijenta(String jmbg, String imePacijenta, String prezimePacijenta, int stepenBolesti, int idBrojIzabranogDoktora);
   /** @param jmbgPacijenta 
    * @param imePacijenta 
    * @param prezimePacijenta 
    * @param stepenBolesti
    * @pdOid 7567cf30-49b1-4303-9053-7aed00a346ef */
   void azurirajPacijenta(String jmbgPacijenta, String imePacijenta, String prezimePacijenta, int stepenBolesti);
   /** *  @param idBroj
     * @return 
    * @pdOid a9a93551-c7a9-4fdf-ae94-4199113a51d3 */
   List<Pacijent> prikazSvihPacijenata(int idBroj);
   /**
     * @return  *  @pdOid d11f95ab-fb47-4beb-bd50-3918c31469c3 */
   boolean potvrdaIzmene();

}