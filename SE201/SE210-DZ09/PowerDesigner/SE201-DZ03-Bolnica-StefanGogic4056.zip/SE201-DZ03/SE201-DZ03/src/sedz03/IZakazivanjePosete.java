package sedz03;

/***********************************************************************
 * Module:  IZakazivanjePosete.java
 * Author:  User
 * Purpose: Defines the Interface IZakazivanjePosete
 ***********************************************************************/

import java.util.*;

/** @pdOid daeca662-ef77-4411-aa56-dc5e88314f4d */
public interface IZakazivanjePosete {
   /** @pdOid 5d0a082d-65ab-4f94-8e87-1b96862681da */
   void pregledZakazanePosete();
   /** *  @param jmbgPacijenta 
    * @param jmbgPosetioca 
    * @param datumPosete
     * @return 
    * @pdOid 350810d3-8fa7-42c0-96e8-9f173d60d514 */
   boolean mogucnostZakazivanjaPosete(String jmbgPacijenta, String jmbgPosetioca, Date datumPosete);
   /** *  @param jmbgPacijenta
     * @return 
    * @pdOid 206959b8-d2e7-46d7-a0cf-f3159510f119 */
   boolean proveraValidnostiJMBG(String jmbgPacijenta);
   /** *  @param jmbgPacijenta
     * @return 
    * @pdOid 42545734-ee0e-428c-b4d5-1a1ae50d066f */
   boolean proveraStepenaBolesti(String jmbgPacijenta);
   /** *  @param jmbgPosetioca
     * @return 
    * @pdOid 52b29def-bd5c-4632-8d9d-c268a8ab7904 */
   List<ZakazanaPoseta> zakazanePosete(String jmbgPosetioca);
   /**
     * @return  *  @pdOid 55796897-4c19-438b-8ef8-a2e641e5628f */
   ZakazanaPoseta prikazZakazanePosete();

}