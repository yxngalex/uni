package sedz03;

/***********************************************************************
 * Module:  Doktor.java
 * Author:  User
 * Purpose: Defines the Class Doktor
 ***********************************************************************/

/** @pdOid 9923ff81-42f6-49d4-9152-bcd0a47345b0 */
public class Doktor extends Osoba {
   /** @pdOid 7326eb4a-2b70-4c68-a8ca-fa81f2d66cfd */
   private int idBroj;
   /** @pdOid 18004206-f3fc-4261-a286-ece8b8ba4c96 */
   private String specijalizacija;
   
   /** @pdRoleInfo migr=no name=ZakazanaPoseta assc=association2 coll=java.util.Collection impl=java.util.HashSet mult=0..* type=Composition */
   public java.util.Collection<ZakazanaPoseta> zakazanaPoseta;
   /** @pdRoleInfo migr=no name=Pacijent assc=association4 mult=0..* type=Composition */
   public Pacijent[] pacijent;
   
   /**
     * @return  *  @pdOid bcdf14ee-0cd5-425e-80b3-a1f89296345d */
   public int getIdBroj() {
      return idBroj;
   }
   
   /** @param newIdBroj
    * @pdOid 87940571-db73-45cb-97d3-e600be96e503 */
   public void setIdBroj(int newIdBroj) {
      idBroj = newIdBroj;
   }
   
   /**
     * @return  *  @pdOid 6d081cf6-45da-44e8-9507-cd8f5e7e0144 */
   public String getSpecijalizacija() {
      return specijalizacija;
   }
   
   /** @param newSpecijalizacija
    * @pdOid 178c3402-a30c-4794-a17f-fee8c1f5b479 */
   public void setSpecijalizacija(String newSpecijalizacija) {
      specijalizacija = newSpecijalizacija;
   }
   
   /** @pdOid 4ebaaf4b-ce4c-4dd7-be33-9f8afd7e4e25 */
   public Doktor() {
      // TODO: implement
   }
   
   /** @param ime 
    * @param prezime 
    * @param idBroj 
    * @param specijalizacija
    * @pdOid 36e9833c-9e77-47fe-b57c-be03f4be74c8 */
   public Doktor(String ime, String prezime, int idBroj, String specijalizacija) {
      // TODO: implement
   }
   
   
   /**
     * @return  *  @pdGenerated default getter */
   public java.util.Collection<ZakazanaPoseta> getZakazanaPoseta() {
      if (zakazanaPoseta == null)
         zakazanaPoseta = new java.util.HashSet<>();
      return zakazanaPoseta;
   }
   
   /**
     * @return  *  @pdGenerated default iterator getter */
   public java.util.Iterator getIteratorZakazanaPoseta() {
      if (zakazanaPoseta == null)
         zakazanaPoseta = new java.util.HashSet<>();
      return zakazanaPoseta.iterator();
   }
   
   /** @pdGenerated default setter
     * @param newZakazanaPoseta */
   public void setZakazanaPoseta(java.util.Collection<ZakazanaPoseta> newZakazanaPoseta) {
      removeAllZakazanaPoseta();
      for (java.util.Iterator iter = newZakazanaPoseta.iterator(); iter.hasNext();)
         addZakazanaPoseta((ZakazanaPoseta)iter.next());
   }
   
   /** @pdGenerated default add
     * @param newZakazanaPoseta */
   public void addZakazanaPoseta(ZakazanaPoseta newZakazanaPoseta) {
      if (newZakazanaPoseta == null)
         return;
      if (this.zakazanaPoseta == null)
         this.zakazanaPoseta = new java.util.HashSet<>();
      if (!this.zakazanaPoseta.contains(newZakazanaPoseta))
         this.zakazanaPoseta.add(newZakazanaPoseta);
   }
   
   /** @pdGenerated default remove
     * @param oldZakazanaPoseta */
   public void removeZakazanaPoseta(ZakazanaPoseta oldZakazanaPoseta) {
      if (oldZakazanaPoseta == null)
         return;
      if (this.zakazanaPoseta != null)
         if (this.zakazanaPoseta.contains(oldZakazanaPoseta))
            this.zakazanaPoseta.remove(oldZakazanaPoseta);
   }
   
   /** @pdGenerated default removeAll */
   public void removeAllZakazanaPoseta() {
      if (zakazanaPoseta != null)
         zakazanaPoseta.clear();
   }

}