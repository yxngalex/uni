package sedz03;


import java.util.*;

/** @pdOid eb6bfa9e-c507-41d6-a7d9-8271890e4ffb */
public class Pacijent extends Osoba implements IAdministracijaPacijenta {
   /** @pdOid ff92c9a0-d505-4bcd-9e1a-09b012fa3e4b */
   private int stepenBolesti;
   /** @pdOid f5e4f45d-8f17-4baf-9dc6-094a3bb36bf9 */
   private int idBrojIzabranogDoktora;
   /** @pdOid 53e37596-eee4-45db-ba6e-e811d206e143 */
   private String jmbg;
   
   /** @pdRoleInfo migr=no name=ZakazanaPoseta assc=association3 coll=java.util.Collection impl=java.util.HashSet mult=0..* type=Composition */
   public java.util.Collection<ZakazanaPoseta> zakazanaPoseta;
   
   /**
     * @return  *  @pdOid 84c1bf25-73ba-405a-ae2c-21292c8d75f3 */
   public int getStepenBolesti() {
      return stepenBolesti;
   }
   
   /** @param newStepenBolesti
    * @pdOid 6483dcb1-e07b-4395-aa48-788c4d5729ac */
   public void setStepenBolesti(int newStepenBolesti) {
      stepenBolesti = newStepenBolesti;
   }
   
   /**
     * @return  *  @pdOid 341d6bfe-fa44-4e47-b2b5-355a5943a320 */
   public int getIdBrojIzabranogDoktora() {
      return idBrojIzabranogDoktora;
   }
   
   /** @param newIdBrojIzabranogDoktora
    * @pdOid c4863896-b194-4bae-abe7-5b747cf0c0dd */
   public void setIdBrojIzabranogDoktora(int newIdBrojIzabranogDoktora) {
      idBrojIzabranogDoktora = newIdBrojIzabranogDoktora;
   }
   
   /**
     * @return  *  @pdOid 034d31c0-09ef-44d5-a270-c6d727074985 */
   public String getJmbg() {
      return jmbg;
   }
   
   /** @param newJmbg
    * @pdOid 1612bef5-de4b-4c24-943d-b6316eebb73a */
   public void setJmbg(String newJmbg) {
      jmbg = newJmbg;
   }
   
   /** @pdOid 2fc57128-8252-4405-bfe4-f926d67e4c3a */
   public Pacijent() {
      // TODO: implement
   }
   
   /** @param ime 
    * @param prezime 
    * @param stepenBolesti 
    * @param idIzabranogDoktora 
    * @param jmbg
    * @pdOid 666a80ce-e783-430f-bde9-4c9c82d343bc */
   public Pacijent(String ime, String prezime, int stepenBolesti, int idIzabranogDoktora, String jmbg) {
      // TODO: implement
   }
   
   /** @param jmbgPacijenta
    * @pdOid 8f8a8600-69b2-4531-a706-59281f57aba8 */
   @Override
   public void obrisiPacijenta(String jmbgPacijenta) {
      // TODO: implement
   }
   
   /** @param jmbgPacijenta
    * @pdOid 07d8c6f2-4f54-47bc-850d-061e61d6a964 */
   @Override
   public Pacijent pogledajPodatkeOPacijentu(String jmbgPacijenta) {
      // TODO: implement
      return null;
   }
   
   /** @param jmbg 
    * @param imePacijenta 
    * @param prezimePacijenta 
    * @param stepenBolesti 
    * @param idBrojIzabranogDoktora
    * @pdOid fd51b1b7-d369-44be-b70e-fc0f2474e8f6 */
   public void dodajPacijenta(String jmbg, String imePacijenta, String prezimePacijenta, int stepenBolesti, int idBrojIzabranogDoktora) {
      // TODO: implement
   }
   
   /** @param jmbgPacijenta 
    * @param imePacijenta 
    * @param prezimePacijenta 
    * @param stepenBolesti
    * @pdOid 48387a36-ea34-4601-a395-d9581bc2c02d */
   @Override
   public void azurirajPacijenta(String jmbgPacijenta, String imePacijenta, String prezimePacijenta, int stepenBolesti) {
      // TODO: implement
   }
   
   /** @param idBroj
    * @pdOid fe2c3cb9-684b-4259-b475-ffbd670666b6 */
   @Override
   public List<Pacijent> prikazSvihPacijenata(int idBroj) {
      // TODO: implement
      return null;
   }
   
   
   /**
     * @return  *  @pdGenerated default getter */
   public java.util.Collection<ZakazanaPoseta> getZakazanaPoseta() {
      if (zakazanaPoseta == null)
         zakazanaPoseta = new java.util.HashSet<>();
      return zakazanaPoseta;
   }
   
   /**
     * @return  *  @pdGenerated default iterator getter */
   public java.util.Iterator getIteratorZakazanaPoseta() {
      if (zakazanaPoseta == null)
         zakazanaPoseta = new java.util.HashSet<>();
      return (Iterator) zakazanaPoseta;//.iterator();
   }
   
   /** @pdGenerated default setter
     * @param newZakazanaPoseta */
   public void setZakazanaPoseta(java.util.Collection<ZakazanaPoseta> newZakazanaPoseta) {
      removeAllZakazanaPoseta();
      for (java.util.Iterator iter = (java.util.Iterator) newZakazanaPoseta; iter.hasNext();)
         addZakazanaPoseta((ZakazanaPoseta)iter.next());
   }
   
   /** @pdGenerated default add
     * @param newZakazanaPoseta */
   public void addZakazanaPoseta(ZakazanaPoseta newZakazanaPoseta) {
      if (newZakazanaPoseta == null)
         return;
      if (this.zakazanaPoseta == null)
         this.zakazanaPoseta = new java.util.HashSet<>();
      if (!this.zakazanaPoseta.contains(newZakazanaPoseta))
         this.zakazanaPoseta.add(newZakazanaPoseta);
   }
   
   /** @pdGenerated default remove
     * @param oldZakazanaPoseta */
   public void removeZakazanaPoseta(ZakazanaPoseta oldZakazanaPoseta) {
      if (oldZakazanaPoseta == null)
         return;
      if (this.zakazanaPoseta != null)
         if (this.zakazanaPoseta.contains(oldZakazanaPoseta))
            this.zakazanaPoseta.remove(oldZakazanaPoseta);
   }
   
   /** @pdGenerated default removeAll */
   public void removeAllZakazanaPoseta() {
      if (zakazanaPoseta != null)
         zakazanaPoseta.clear();
   }

    public boolean potvrdaIzmene() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}