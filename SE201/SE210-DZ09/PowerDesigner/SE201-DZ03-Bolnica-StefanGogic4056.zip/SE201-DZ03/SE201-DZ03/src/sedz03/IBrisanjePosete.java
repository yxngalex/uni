package sedz03;

/***********************************************************************
 * Module:  IBrisanjePosete.java
 * Author:  User
 * Purpose: Defines the Interface IBrisanjePosete
 ***********************************************************************/

import java.util.*;

/** @pdOid 3bec13a4-88ef-4957-8187-9c5970ae09f9 */
public interface IBrisanjePosete {
   /** *  @param jmbgPacijenta 
    * @param jmbgPosetioca 
    * @param datumPosete
     * @return 
    * @pdOid 04bf884f-4ccf-4a66-94bd-3cf679b456ca */
    boolean obrisanaPoseta(String jmbgPacijenta, String jmbgPosetioca, Date datumPosete);
   /** *  @param jmbg
     * @return 
    * @pdOid b5bb1c2e-0e90-47d1-b8cb-e0bc7f794bad */
   List<ZakazanaPoseta> prikazZakazanihPoseta(String jmbg);
   /**
     * @return  *  @pdOid 937f6d7e-cfdc-4f31-9654-dd6092372769 */
   boolean potvrdaBrisanjaPosete();

}