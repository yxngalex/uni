package sedz03;

/***********************************************************************
 * Module:  Posetilac.java
 * Author:  User
 * Purpose: Defines the Class Posetilac
 ***********************************************************************/

/** @pdOid 837b318f-d0d9-4936-8e3e-c831d25a6f72 */
public class Posetilac extends Osoba {
   /** @pdOid 176d61ad-b739-4348-9143-324abf44625a */
   private String brojTelefona;
   /** @pdOid 7b774835-cb55-49ff-b7fa-865d90740216 */
   private String jmbg;
   
   /** @pdRoleInfo migr=no name=ZakazanaPoseta assc=association1 coll=java.util.Collection impl=java.util.HashSet mult=0..* type=Composition */
   public java.util.Collection<ZakazanaPoseta> zakazanaPoseta;
   
   /**
     * @return  *  @pdOid f059177f-9ea1-4c17-8ad6-05f1be5bd043 */
   public String getBrojTelefona() {
      return brojTelefona;
   }
   
   /** @param newBrojTelefona
    * @pdOid 9390a9fb-15e9-48ee-9241-b90f206443d8 */
   public void setBrojTelefona(String newBrojTelefona) {
      brojTelefona = newBrojTelefona;
   }
   
   /**
     * @return  *  @pdOid 41ff190d-64d5-43be-9cba-15c2fc4b43ad */
   public String getJmbg() {
      return jmbg;
   }
   
   /** @param newJmbg
    * @pdOid f9847614-8f1e-438c-b8f8-e418e385fa43 */
   public void setJmbg(String newJmbg) {
      jmbg = newJmbg;
   }
   
   /** @pdOid 5e6501f3-add7-4702-91a5-64357ad2e196 */
   public Posetilac() {
      // TODO: implement
   }
   
   /** @param brojTelefona 
    * @param jmbg 
    * @param ime 
    * @param prezime
    * @pdOid ec35e820-6028-4265-9a41-1ea332e934d6 */
   public Posetilac(String brojTelefona, String jmbg, String ime, String prezime) {
      // TODO: implement
   }
   
   
   /**
     * @return  *  @pdGenerated default getter */
   public java.util.Collection<ZakazanaPoseta> getZakazanaPoseta() {
      if (zakazanaPoseta == null)
         zakazanaPoseta = new java.util.HashSet<>();
      return zakazanaPoseta;
   }
   
   /**
     * @return  *  @pdGenerated default iterator getter */
   public java.util.Iterator getIteratorZakazanaPoseta() {
      if (zakazanaPoseta == null)
         zakazanaPoseta = new java.util.HashSet<>();
      return zakazanaPoseta.iterator();
   }
   
   /** @pdGenerated default setter
     * @param newZakazanaPoseta */
   public void setZakazanaPoseta(java.util.Collection<ZakazanaPoseta> newZakazanaPoseta) {
      removeAllZakazanaPoseta();
      for (java.util.Iterator iter = newZakazanaPoseta.iterator(); iter.hasNext();)
         addZakazanaPoseta((ZakazanaPoseta)iter.next());
   }
   
   /** @pdGenerated default add
     * @param newZakazanaPoseta */
   public void addZakazanaPoseta(ZakazanaPoseta newZakazanaPoseta) {
      if (newZakazanaPoseta == null)
         return;
      if (this.zakazanaPoseta == null)
         this.zakazanaPoseta = new java.util.HashSet<>();
      if (!this.zakazanaPoseta.contains(newZakazanaPoseta))
         this.zakazanaPoseta.add(newZakazanaPoseta);
   }
   
   /** @pdGenerated default remove
     * @param oldZakazanaPoseta */
   public void removeZakazanaPoseta(ZakazanaPoseta oldZakazanaPoseta) {
      if (oldZakazanaPoseta == null)
         return;
      if (this.zakazanaPoseta != null)
         if (this.zakazanaPoseta.contains(oldZakazanaPoseta))
            this.zakazanaPoseta.remove(oldZakazanaPoseta);
   }
   
   /** @pdGenerated default removeAll */
   public void removeAllZakazanaPoseta() {
      if (zakazanaPoseta != null)
         zakazanaPoseta.clear();
   }

}