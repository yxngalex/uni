package sedz03;


import java.util.*;

/** @pdOid 5e9e8151-b6d8-4f1e-90be-23091ecb9ca6 */
public class ZakazanaPoseta implements IZakazivanjePosete, IBrisanjePosete {
   /** @pdOid 3a84faff-1744-4f4f-918b-e587edd07cd4 */
   private String jmbgPacijenta;
   /** @pdOid f66cf158-3f44-49fb-a723-60f7e97f5b8e */
   private String jmbgPosetioca;
   /** @pdOid ddc2b3d0-c062-470d-8b62-51196ade165f */
   private Date datumPosete;
   
   /** @pdOid e04296c2-5bf5-4319-936b-cd6fd3014ea4 */
   public ZakazanaPoseta() {
      // TODO: implement
   }
   
   /** @param jmbgPacijenta 
    * @param jmbgPosetioca 
    * @param datumPosete
    * @pdOid f35c29c9-84bb-4e84-b1ce-adebc681d708 */
   public ZakazanaPoseta(String jmbgPacijenta, String jmbgPosetioca, Date datumPosete) {
      // TODO: implement
   }
   
   /**
     * @return  *  @pdOid 81aee686-379d-40fc-af1a-17e6b5d68e6b */
   public String getJmbgPacijenta() {
      return jmbgPacijenta;
   }
   
   /** @param newJmbgPacijenta
    * @pdOid a8616e07-cd56-4a3b-bca0-0aa665cc4dbb */
   public void setJmbgPacijenta(String newJmbgPacijenta) {
      jmbgPacijenta = newJmbgPacijenta;
   }
   
   /**
     * @return  *  @pdOid 8618817d-8319-4b0d-ab30-192a047494e2 */
   public String getJmbgPosetioca() {
      return jmbgPosetioca;
   }
   
   /** @param newJmbgPosetioca
    * @pdOid 3e3e8625-e07a-4569-8e38-6152a0446336 */
   public void setJmbgPosetioca(String newJmbgPosetioca) {
      jmbgPosetioca = newJmbgPosetioca;
   }
   
   /**
     * @return  *  @pdOid 2f9e8ee7-3ff2-4085-a8d9-7bfdd9a19f27 */
   public Date getDatumPosete() {
      return datumPosete;
   }
   
   /** @param newDatumPosete
    * @pdOid 9ee05c33-f5bd-4c4b-866f-22e7075c39ef */
   public void setDatumPosete(Date newDatumPosete) {
      datumPosete = newDatumPosete;
   }
   
   /** @param jmbgPacijenta 
    * @param jmbgPosetioca 
    * @param datumPosete
    * @pdOid 120dacb0-10a6-4bf3-a05a-3a6c24690747 */
   @Override
   public boolean mogucnostZakazivanjaPosete(String jmbgPacijenta, String jmbgPosetioca, Date datumPosete) {
      // TODO: implement
      return false;
   }
   
   /** @param jmbgPacijenta
    * @pdOid 55e6b4e3-868c-4090-962f-70637954da9a */
   @Override
   public boolean proveraValidnostiJMBG(String jmbgPacijenta) {
      // TODO: implement
      return false;
   }
   
   /** @param jmbgPacijenta
    * @pdOid 6e5513f9-0c24-4b56-afa1-6d0685364de1 */
   @Override
   public boolean proveraStepenaBolesti(String jmbgPacijenta) {
      // TODO: implement
      return false;
   }
   
   /** @param jmbgPacijenta 
    * @param jmbgPosetioca 
    * @param datumPosete
    * @pdOid ffe86413-3fa7-4cdf-ad0a-f884a56d4ba8 */
   @Override
   public  boolean obrisanaPoseta(String jmbgPacijenta, String jmbgPosetioca, Date datumPosete) {
      // TODO: implement
      return true;
   }

    @Override
    public void pregledZakazanePosete() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<ZakazanaPoseta> zakazanePosete(String jmbgPosetioca) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ZakazanaPoseta prikazZakazanePosete() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<ZakazanaPoseta> prikazZakazanihPoseta(String jmbg) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean potvrdaBrisanjaPosete() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}